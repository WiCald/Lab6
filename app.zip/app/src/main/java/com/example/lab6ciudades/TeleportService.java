package com.example.lab6ciudades;

import retrofit2.Call;
import retrofit2.http.GET;

public interface TeleportService {
    @GET("api/urban_areas/")
    Call<List<UrbanArea>> getUrbanAreas();
}
