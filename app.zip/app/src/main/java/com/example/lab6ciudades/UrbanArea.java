package com.example.lab6ciudades;

public class UrbanArea {
    private String slug;
    private String href;

}
