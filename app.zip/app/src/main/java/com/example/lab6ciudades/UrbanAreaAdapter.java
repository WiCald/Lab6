package com.example.lab6ciudades;

public class UrbanAreaAdapter {
    public class UrbanAreaAdapter extends RecyclerView.Adapter<UrbanAreaAdapter.UrbanAreaViewHolder> {
        // Implementa los métodos necesarios: onCreateViewHolder, onBindViewHolder, getItemCount

        // ViewHolder interno
        public class UrbanAreaViewHolder extends RecyclerView.ViewHolder {
            // Define los elementos de la vista aquí, por ejemplo, TextViews
        }
    }
