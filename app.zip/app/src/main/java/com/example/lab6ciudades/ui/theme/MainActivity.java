package com.example.lab6ciudades.ui.theme;

public class MainActivity extends AppCompatActivity {
    // Variables miembro como RecyclerView, adaptador, etc.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialización y configuración
    }
}
